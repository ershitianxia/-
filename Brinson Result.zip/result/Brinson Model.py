import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import datetime as dt
# you need to consider the change of component of HSCEI during the duration
# Step 1: 由于在2019/06/03-2019/08/21期间，HSCEI成分股发生了变化，所以我们找到更改成分股的日期，考察更改前后各期HSCEI的收益分解
# Step 2：将期初的表格和上述期末的表格合并
# Step 3：计算（1）R^p,R^B,r_{i}^{B},r_{i}^{p};（2）收益分解各项，从而形成完整结果表格
# Step 4：画柱状图

def draw_price_change(file_list_HSI,file_list_HSCEI):
    HSI_price = []
    HSI_return =[0]
    HSCEI_price = []
    HSCEI_return = [0]
    for file in file_list_HSCEI:
        file_path = './恒生国企指数权重（比较的组合）/CSV_Format/%s'%file
        current_HSCEI_data = pd.read_csv(file_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
        current_HSCEI_data['weighted price'] = current_HSCEI_data['Closing Price']*current_HSCEI_data['Weighting (%)']
        HSCEI_price.append(np.sum(current_HSCEI_data['weighted price']))
    for file in file_list_HSI:
        file_path = './恒生指数权重（基准）/CSV_Format/%s'%file
        current_HSI_data = pd.read_csv(file_path,header=1,encoding='UTF-16 LE',sep ='\t',parse_dates=['Trade Date'])
        current_HSI_data['weighted price'] = current_HSI_data['Closing Price']*current_HSI_data['Weighting (%)']
        HSI_price.append(np.sum(current_HSI_data['weighted price']))
    for i in range(len(HSCEI_price)-1):
        HSCEI_return.append(np.log(HSCEI_price[i+1]/HSCEI_price[0]))
        HSI_return.append(np.log(HSI_price[i+1]/HSI_price[0]))
    plt.figure('Return Change')
    x = [i[4:14] for i in file_list_HSI]
    plt.plot(x,HSCEI_return,label='HSCEI',color = 'red')
    plt.plot(x,HSI_return,label='HSI',color='rosybrown')
    plt.vlines('2019_06_17',-0.1,0.15,colors='orange',linestyles='dashed')
    plt.xticks(rotation=90)
    plt.legend()
    plt.tight_layout()
    plt.show()


# Step 1:
def find_the_componet_change():
    previous_HSCEI_dict = {}
    count = 0
    file_no = 0
    for file in file_list_HSCEI:
        file_path = './恒生国企指数权重（比较的组合）/CSV_Format/%s'%file
        current_HSCEI_data = pd.read_csv(file_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
    #Index(['Trade Date', 'Index', 'Stock Code', 'Stock Name', 'Stock Name.1',
    #   'Exchange Listed', 'Industry', 'Trading Currency', 'Closing Price',
    #   '% Change', 'Index Point Contribution', 'Weighting (%)'],
        current_HSCEI_list = current_HSCEI_data['Stock Code']
        current_HSCEI_set = set(current_HSCEI_list)
        current_HSCEI_date = current_HSCEI_data['Trade Date'].iloc[0]
        if previous_HSCEI_dict =={}:
            previous_HSCEI_dict[0] = (current_HSCEI_list,current_HSCEI_date)
            file_no += 1
            print('we have finished ', file_no, 'th file')
        elif current_HSCEI_set != set(previous_HSCEI_dict[count][0]):
            count += 1
            file_no += 1
            previous_HSCEI_dict[count] = (current_HSCEI_list,current_HSCEI_date)
            print('the component has been changed on ',current_HSCEI_date)
            print('we have finished ', file_no, 'th file')
        else:
            file_no += 1
            print('we have finished ', file_no, 'th file')
            continue
    return previous_HSCEI_dict
# so we need (19/06/03, 19/06/16),(19/06/17,19/08/21) csv file
# Step 2:
def merge_HSCEI_begin_end(start_date,end_date):
    start_path = './恒生国企指数权重（比较的组合）/CSV_Format/HSCEI_%s.csv'%start_date
    end_path = './恒生国企指数权重（比较的组合）/CSV_Format/HSCEI_%s.csv'%end_date
    start_dataset = pd.read_csv(start_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
    end_dataset = pd.read_csv(end_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
    start_dataset = start_dataset[['Stock Code','Industry','Closing Price','Weighting (%)']]
    start_dataset.columns =['Stock Code','Industry','Closing Price_start','Weight']
    start_dataset['Weight'] = start_dataset['Weight'].map(lambda x: x * 0.01)
    end_dataset = end_dataset[['Stock Code','Closing Price']]
    end_dataset.columns = ['Stock Code','Closing Price_end']
    merged_dataset = pd.merge(start_dataset,end_dataset,how='outer',on='Stock Code')
    merged_dataset['return'] = np.log(merged_dataset['Closing Price_end'] / merged_dataset['Closing Price_start'])
    merged_dataset['weighted return'] = merged_dataset['return'] * merged_dataset['Weight']
    return merged_dataset

def merge_HSI_bigin_end(start_date,end_date):
    start_path = './恒生指数权重（基准）/CSV_Format/HSI_%s.csv'%start_date
    end_path = './恒生指数权重（基准）/CSV_Format/HSI_%s.csv'%end_date
    start_dataset = pd.read_csv(start_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
    end_dataset = pd.read_csv(end_path,header=1,encoding='UTF-16 LE',sep='\t',parse_dates=['Trade Date'])
    start_dataset = start_dataset[['Stock Code','Industry','Closing Price','Weighting (%)']]
    start_dataset.columns =['Stock Code','Industry','Closing Price_start','Weight']
    start_dataset['Weight'] = start_dataset['Weight'].map(lambda x:x*0.01)
    end_dataset = end_dataset[['Stock Code','Closing Price']]
    end_dataset.columns = ['Stock Code','Closing Price_end']
    merged_dataset = pd.merge(start_dataset,end_dataset,how='outer',on='Stock Code')
    merged_dataset['return'] = np.log(merged_dataset['Closing Price_end']/merged_dataset['Closing Price_start'])
    merged_dataset['weighted return'] = merged_dataset['return']*merged_dataset['Weight']
    return merged_dataset
# Step 3:
# we use the weight and industry division on start day instead of end day
def calculate_R(data):
    R = np.sum(data['weighted return'])/np.sum(data['Weight'])
    return R

def return_decomposition(HSCEI_dataset,HSI_dataset,R_B,R_p,s):
    return_decomposed_data = pd.DataFrame()
    group_by_HSCEI_dataset = HSCEI_dataset.groupby('Industry')
    group_by_HSI_dataset = HSI_dataset.groupby('Industry')
    # calculate w_i
    return_decomposed_data['w_{i}^{p}'] = group_by_HSCEI_dataset.sum()['Weight']
    return_decomposed_data['w_{i}^{B}'] = group_by_HSI_dataset.sum()['Weight']
    # calculate r_i
    HSCEI_merge_with_wi = pd.merge(HSCEI_dataset,return_decomposed_data['w_{i}^{p}'],how='left',left_on='Industry',right_index=True)
    HSI_merge_with_wi = pd.merge(HSI_dataset,return_decomposed_data['w_{i}^{B}'],how='left',left_on='Industry',right_index=True)
    HSCEI_merge_with_wi['weighted return by industry'] = HSCEI_merge_with_wi['weighted return']/HSCEI_merge_with_wi['w_{i}^{p}']
    HSI_merge_with_wi['weighted return by industry'] = HSI_merge_with_wi['weighted return']/HSI_merge_with_wi['w_{i}^{B}']
    # now we can decompose the return
    grouped_again_HSCEI = HSCEI_merge_with_wi.groupby('Industry')
    grouped_again_HSI = HSI_merge_with_wi.groupby('Industry')
    return_decomposed_data['r_{i}^{p}'] = grouped_again_HSCEI.sum()['weighted return by industry']
    return_decomposed_data['r_{i}^{B}'] = grouped_again_HSI.sum()['weighted return by industry']
    return_decomposed_data['R_B'] = R_B
    return_decomposed_data['Allocation Effect'] = (return_decomposed_data['w_{i}^{p}']-return_decomposed_data['w_{i}^{B}'])*(return_decomposed_data['r_{i}^{B}']-return_decomposed_data['R_B'])
    return_decomposed_data['Stock Selection Effect'] = return_decomposed_data['w_{i}^{p}']*(return_decomposed_data['r_{i}^{p}']-return_decomposed_data['r_{i}^{B}'])
    return_decomposed_data['Intersection Effect'] = (return_decomposed_data['w_{i}^{p}']-return_decomposed_data['w_{i}^{B}'])*(return_decomposed_data['r_{i}^{p}']-return_decomposed_data['r_{i}^{B}'])
    return_decomposed_data['Extra Return'] = return_decomposed_data['Allocation Effect']+return_decomposed_data['Stock Selection Effect']+return_decomposed_data['Intersection Effect']
    return_decomposed_data.loc['SUM'] =np.sum(return_decomposed_data)
    # we can save the data into a csv file
    return_decomposed_data.to_csv('./return decomposition result_%s.csv'%s)
    return return_decomposed_data

#Step 4:
def draw_chart(data,s,start_date,end_date):
    labels = data.index.values
    labels = [x.split(' ')[-1] for x in labels]
    labels = labels[:-1]
    allocation_effect = data['Allocation Effect'].iloc[:-1]
    stock_selection = data['Stock Selection Effect'].iloc[:-1]
    Intersection = data['Intersection Effect'].iloc[:-1]

    x = np.arange(len(labels))  # the label locations
    width = 0.25  # the width of the bars
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    fig = plt.figure(s)
    ax = fig.add_subplot(1,1,1)
    rectangle_1 = ax.bar(x - width, allocation_effect, width, label='资产配置',color= 'rosybrown')
    rectangle_2 = ax.bar(x,stock_selection,width,label = '选股效应',color='lightcoral')
    rectangle_3 = ax.bar(x + width, Intersection, width, label='交互作用',color='indianred')

    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_title('第%s区间的收益分解(%s - %s)'%(s,start_date,end_date))
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    fig.show()
    fig.tight_layout()
    fig.savefig('Return Decomposition of Duration%s(%s - %s).png'%(s,start_date,end_date))

if __name__ == '__main__':
    file_list_HSCEI = os.listdir('./恒生国企指数权重（比较的组合）/CSV_Format')
    file_list_HSI = os.listdir('./恒生指数权重（基准）/CSV_Format')
    print('totally we have ', len(file_list_HSCEI), 'csv files')
    draw_price_change(file_list_HSI,file_list_HSCEI)
    previous_component_dict = find_the_componet_change()
    print(previous_component_dict[0][0])
    print('')
    print(previous_component_dict[1][0])
    start_1 = '2019_06_03'
    end_1 = previous_component_dict[1][1] + dt.timedelta(days=-3)
    end_1 = dt.datetime.strftime(end_1, '%Y_%m_%d')
    start_2 = dt.datetime.strftime(previous_component_dict[1][1], '%Y_%m_%d')
    end_2 = '2019_08_21'
    merged_HSCEI_dataset_1 = merge_HSCEI_begin_end(start_1, end_1)
    merged_HSI_dataset_1 = merge_HSI_bigin_end(start_1, end_1)
    R_p_1 = calculate_R(merged_HSCEI_dataset_1)
    R_B_1 = calculate_R(merged_HSI_dataset_1)
    result_1 = return_decomposition(merged_HSCEI_dataset_1,merged_HSI_dataset_1,R_B_1,R_p_1,1)
    draw_chart(result_1,1,start_1,end_1)
    print('we have completed duration 1,the R_p=%.3f and R_B = %.3f'%(R_p_1,R_B_1))
    merged_HSCEI_dataset_2 = merge_HSCEI_begin_end(start_2, end_2)
    merged_HSI_dataset_2 = merge_HSI_bigin_end(start_2, end_2)
    R_p_2 = calculate_R(merged_HSCEI_dataset_2)
    R_B_2 = calculate_R(merged_HSI_dataset_2)
    result_2 = return_decomposition(merged_HSCEI_dataset_2,merged_HSI_dataset_2,R_B_2,R_p_2,2)
    draw_chart(result_2,2,start_2,end_2)
    print('we have completed duration 2')